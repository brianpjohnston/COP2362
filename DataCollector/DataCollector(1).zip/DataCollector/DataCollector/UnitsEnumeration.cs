﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCollector
{
    //Public enumeration to symbolically represent the units Metric and Imperial
    public enum UnitsEnumeration
    {
        //Values to represent Metric and Imperial units
        Metric, 
        Imperial
    }
}
